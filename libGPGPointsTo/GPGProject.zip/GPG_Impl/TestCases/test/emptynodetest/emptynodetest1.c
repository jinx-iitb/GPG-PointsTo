int *p,*q,a,b;

int main(){

    a=30;
	p=&a;
	b=40;

}