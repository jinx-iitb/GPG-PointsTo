
int a,b,c;

main(){

 a=20;

 b=a;

 c=b;


}