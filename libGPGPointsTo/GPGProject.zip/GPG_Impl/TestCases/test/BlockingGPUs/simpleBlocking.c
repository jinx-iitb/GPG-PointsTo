int **p;
int *x,*y,*z;
int a,b,c;

void f(){
	
   x=&b;
}

int main(){
	//p=&x;

    //*p=&a;
    f();

}