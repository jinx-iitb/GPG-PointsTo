int **p,**q,**r;

int *a,*b,*c,*d,*e;

int m;
int main(){

   do {

      r=&a;
      *q=&m;
      if(m)   q = &b;
      else    break;

    } while(1);

    e=*p;
    q=&e;

}