int *x,*y,*z,**p,a,b,c;


main(){
	x=&a;
	y=&b;
    *p=&a;
	z=&c;
	y=&c;
}