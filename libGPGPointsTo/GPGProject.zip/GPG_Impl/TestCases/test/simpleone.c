int **p,**q;
int *x,*y,*z;
int a,b;



int main(){

  // y=&a;

  // x=y;

   p=&x;


   z=&a;
   y=&b;

  *p=y;

  //q=&z;

  //*p=*q;

}




