
int a,b,c,d;

int *x,*y,*z;
void f(){

  while(c){
   y=x;
   z=y;
   x=&c;   
 }

}

int main(){

  x=&a;

  f();
}

