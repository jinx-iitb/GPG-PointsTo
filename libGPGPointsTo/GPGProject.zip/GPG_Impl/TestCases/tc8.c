#include <stdio.h>
int **p, **q, **r, *x, *y, *z, a, b, c;
int main(){    
    if(a > 10){
        y = &b;        
    }
    else{
        z = &c;        
    }
    z = x;    
    return 0;
}