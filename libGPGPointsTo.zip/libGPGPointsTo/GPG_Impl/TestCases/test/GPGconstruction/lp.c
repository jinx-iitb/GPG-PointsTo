
int *x,*y,a,b,c;

int main(){
	
//	y=&a;

	while(b>100){

        // if(c)
	  y=&b;
        //else
         // x=&c;
        }

    x=&b;

    x=y;


    *x=20;

}
