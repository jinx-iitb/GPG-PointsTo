#include<stdio.h>

int a,b,c,d;
int main(){

  int a,b;
  int **p,**q;
  int *x,*y;

   p=&x;

 if(a)
  x=&a;
 else{
  x=&b;
  }



  **p=30;
//  **q=40;

printf("%d%d",a,b);
 
}
