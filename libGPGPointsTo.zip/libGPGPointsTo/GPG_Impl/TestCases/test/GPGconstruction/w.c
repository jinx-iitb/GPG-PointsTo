
#include<stdio.h>

int **p,**q;
int *x,*y;
int a,b,c,d;

int main(){
   //scanf("%d",&a);

int e;

x=&e;

*x=30;

}
