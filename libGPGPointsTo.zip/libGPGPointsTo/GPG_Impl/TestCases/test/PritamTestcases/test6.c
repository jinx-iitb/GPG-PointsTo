#include<stdio.h>
#include<stdlib.h>

int *x, *y;

int main()
{
	x = (int *)malloc(sizeof(int));
	x = (int *)malloc(sizeof(int));
	x = (int *)calloc(2, sizeof(int));
}
