void INITIALGPU(long lineno, char *gpu){

}

void INTERMEDIATEGPU(long lineno, char *gpu){

}

void POINTSTO(void *p, char *listOfNames){

}

void NOTPOINTSTO(void *p, char *listOfNames){


}

void COALESCE(long lineno1, long lineno2){


}
void NOCOALESCE(long lineno1, long lineno2){

	
}